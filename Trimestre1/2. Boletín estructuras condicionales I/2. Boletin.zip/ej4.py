numero=int(input("Dame tu edad "))

if 0<=numero<6:
    print("Esats en educación infantil")
elif 6<=numero<=11:
    print("Esats en educación primaria")
elif 12<=numero<=16:
     print("Esats en educación secundaria obligatoria")
elif 16<numero:
     print("Esats en Enseñanza post-obligatoria")