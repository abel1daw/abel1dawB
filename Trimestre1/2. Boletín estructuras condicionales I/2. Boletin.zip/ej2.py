numero1=int(input("Dame el primer numero "))
numero2=int(input("Dame el segundo numero "))

if numero1==numero2:
    print("Los numero son iguales ")
elif numero1>numero2:
    print("El primer numero es mayor al segundo ")
else:
    print("El segundo numero es el mayor ")