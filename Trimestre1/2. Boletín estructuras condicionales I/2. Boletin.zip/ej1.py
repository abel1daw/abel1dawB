numero=int(input("Dame un numero "))

if numero%2==0:
    print("El numero es par")
else:
    print("El numero es impar")
