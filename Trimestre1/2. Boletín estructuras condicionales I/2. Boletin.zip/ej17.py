num1=int(input("Dame un numero: "))
num2=int(input("Dame otro numero: "))

if num1<num2:
    print(num2-num1)
elif num2<num1:
    print(num1-num2)