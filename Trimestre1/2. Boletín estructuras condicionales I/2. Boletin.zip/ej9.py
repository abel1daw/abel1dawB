dia=int(input("Dame un dia de la semana (1-7): "))

if dia==1:
    print("Lunes")
elif dia==2:
    print("Martes")
elif dia==3:
    print("Miercoles")
elif dia==4:
    print("Jueves")
elif dia==5:
    print("Viernes")
elif dia==6:
    print("Sabado")
elif dia==7:
    print("Domingo")
else:
    print("Este dia no es valido")